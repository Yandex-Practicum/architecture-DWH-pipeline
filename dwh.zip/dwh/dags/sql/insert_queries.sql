INSERT INTO sample_table (id,order_number,total,discount,buyer_id) VALUES (1, 12345, 1000,100,648821);
INSERT INTO sample_table (id,order_number,total,discount,buyer_id) VALUES (2, 123456, 500,20,6488214);
INSERT INTO sample_table (id,order_number,total,discount,buyer_id) VALUES (3, 123457, 700,10,6488211);
INSERT INTO sample_table (id,order_number,total,discount,buyer_id) VALUES (4, 123458, 200,0,6488219);
INSERT INTO sample_table (id,order_number,total,discount,buyer_id) VALUES (5, 123459, 3000,100,648801);
